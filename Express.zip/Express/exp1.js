const express = require("express");
const app = express();
app.use(express.json()); // Parse JSON body

// ====== Middleware Example ======
const logger = (req, res, next) => {
  console.log(`${req.method} request made to ${req.url}`);
  next();
};
app.use(logger);

// ====== Routes ======

// Home route
app.get("/", (req, res) => {
  res.send("Welcome to ExpressJS Full Example (23B01A4537)");
});

// About route
app.get("/about", (req, res) => {
  res.send("This is 23B01A4537 - About Page");
});

// Route Parameter
app.get("/user/:id", (req, res) => {
  const userId = req.params.id;
  res.send(`User ID from route parameter: ${userId}`);
});

// Query Parameter
// Example: /search?name=John&age=25
app.get("/search", (req, res) => {
  const { name, age } = req.query;
  res.send(`Search Result → Name: ${name}, Age: ${age}`);
});

// URL Builder
app.get("/full-url", (req, res) => {
  const fullUrl = req.protocol + "://" + req.get("host") + req.originalUrl;
  res.send(`Full URL is: ${fullUrl} 23B01A4537`);
});

// ====== HTTP Methods Example ======
let users = []; // In-memory storage

// Create user (POST)
app.post("/user", (req, res) => {
  const { id, name } = req.body;
  if (!id || !name) {
    return res.status(400).send("Please provide both id and name");
  }
  users.push({ id, name });
  res.send(`User added: ${name} (ID: ${id})`);
});

// Retrieve all users (GET)
app.get("/users", (req, res) => {
  res.json(users);
});

// Delete user by ID (DELETE)
app.delete("/user/:id", (req, res) => {
  const userId = req.params.id;
  const initialLength = users.length;
  users = users.filter(user => user.id != userId);
  if (users.length === initialLength) {
    return res.status(404).send(`User with ID ${userId} not found`);
  }
  res.send(`User with ID ${userId} deleted`);
});

// ====== Start Server ======
const PORT = 4000; // Change port if 3000 is in use
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
