var express = require('express');
var router = express.Router();

// Middleware
router.use((req, res, next) => {
  console.log(`${req.method} request to ${req.url}`);
  next();
});

router.get('/', (req, res) => res.send('Welcome to ExpressJS Routing Example!'));
router.get('/user/:id', (req, res) => res.send(`User ID is: ${req.params.id}`));
router.get('/search', (req, res) => res.send(`Searching for: ${req.query.q}`));
router.get('/book/:title/author/:author', (req, res) =>
  res.send(`Book: ${req.params.title}, Author: ${req.params.author}`)
);

module.exports = router;
