const express = require('express'); 
const app = express(); 
const path = require('path'); 

app.set('view engine', 'ejs'); 
app.set('views', path.join(__dirname, 'views')); 

app.get('/', (req, res) => { 
    const student = { name: "Vasanthi", RegNo: "24B05A4502" }; 
    res.render('index', { student }); 
}); 

app.listen(3004, () => { 
    console.log("Server running at http://localhost:3004"); 
});
